package top.xfwork.fogradar

import kotlin.math.*

/** A visible target remains at its latest radar-measured coordinates until expiry. */
data class TrackedView(val x:Double,val y:Double,val color:Int,val distanceM:Int)
private data class Track(var x:Double,var y:Double,val color:Int,var lastSeen:Long,var distanceM:Int)

class TargetTracker {
    private val tracks=mutableListOf<Track>()
    private val palette=intArrayOf(0xFFFF5252.toInt(),0xFFFFD740.toInt(),0xFF00E5FF.toInt(),0xFFB388FF.toInt(),0xFF69F0AE.toInt(),0xFFFF9100.toInt(),0xFFFF80AB.toInt(),0xFF40C4FF.toInt(),0xFFE040FB.toInt(),0xFFEEFF41.toInt(),0xFF7C4DFF.toInt(),0xFF64FFDA.toInt())
    private fun nextColor():Int {
        val used=tracks.map { it.color }.toSet()
        return palette.filter { it !in used }.randomOrNull() ?: palette.random()
    }
    fun measure(snap:Snapshot,p:Params){
        val now=snap.timeMs
        val ttl=(p.keepSeconds*1000).toLong().coerceAtLeast(100)
        tracks.removeAll { now-it.lastSeen>=ttl }
        val measurements=snap.targets.filter {
            it.snr>=p.snrMin && it.speed in p.speedMin..p.speedMax &&
              (p.direction==0 || (p.direction==1&&it.approaching) || (p.direction==2&&!it.approaching))
        }.map { Triple(p.xy(it).first,p.xy(it).second,(it.range+p.rangeBias).coerceAtLeast(0f).toInt()) }
        val options=mutableListOf<Triple<Int,Int,Double>>()
        for(i in measurements.indices) for(j in tracks.indices){
            val d=hypot(measurements[i].first-tracks[j].x,measurements[i].second-tracks[j].y)
            if(d<min(15.0,3.5+0.12*measurements[i].second.coerceAtLeast(0.0))) options.add(Triple(i,j,d))
        }
        val matchedM=mutableSetOf<Int>();val matchedT=mutableSetOf<Int>()
        for((i,j,_) in options.sortedBy { it.third }){
            if(i in matchedM || j in matchedT)continue
            tracks[j].apply {x=measurements[i].first;y=measurements[i].second;lastSeen=now;distanceM=measurements[i].third}
            matchedM.add(i);matchedT.add(j)
        }
        for(i in measurements.indices)if(i !in matchedM) tracks.add(Track(measurements[i].first,measurements[i].second,nextColor(),now,measurements[i].third))
    }
    fun visible(now:Long,seconds:Float):List<TrackedView>{
        val ttl=(seconds*1000).toLong().coerceAtLeast(100)
        tracks.removeAll { now-it.lastSeen>=ttl }
        return tracks.map { TrackedView(it.x,it.y,it.color,it.distanceM) }
    }
    fun confirmedCount(now:Long)=tracks.count { now-it.lastSeen<500 }
}
