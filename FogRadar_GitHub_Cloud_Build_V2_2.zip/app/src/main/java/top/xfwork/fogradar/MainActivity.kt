package top.xfwork.fogradar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.location.*
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensors: SensorManager
    private var lastGyroNs = 0L
    private var yawRate = 0.0
    private val tracks = TargetTracker()
    private var manualSpeedKmh = 0.0
    private var speedKmh = 0.0
    private var useGpsSpeed = false
    private var lastGpsSpeedMs = 0L
    private var lastPhysicsMs = 0L
    private var recordButton: Button? = null
    private var gpsManager: LocationManager? = null
    private val gpsListener = object: LocationListener {
        override fun onLocationChanged(l: Location) {
            if (l.hasSpeed()) { speedKmh=(l.speed*3.6).toDouble().coerceIn(0.0,200.0);lastGpsSpeedMs=SystemClock.elapsedRealtime() }
        }
    }
    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_GYROSCOPE) return
        val ns=e.timestamp
        // The phone must be fixed flat; screen-normal Z approximates vehicle yaw.
        yawRate = e.values[2].toDouble().coerceIn(-2.5,2.5)
        lastGyroNs=ns
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private val serviceUuid = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    private val notifyUuid = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private var gatt: BluetoothGatt? = null
    private var scanning = false
    private var adapter: BluetoothAdapter? = null
    private var connected = false
    private var simulated = false
    private var latest = AtomicReference<Snapshot?>(null)
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("fog_params", MODE_PRIVATE) }
    private var params = Params()
    private lateinit var radarView: RadarView
    private lateinit var status: TextView
    private lateinit var primary: LinearLayout
    private lateinit var btnConnect: Button
    private var blePacketCount = 0L
    private var lastBleAt = 0L
    private var frameCount = 0L
    private var recentFrame = 0L
    private var logWriter: java.io.BufferedWriter? = null
    // Only manage FogRadar session logs; never touch other applications' directories.
    private val logMaxAgeMs = 7L * 24 * 60 * 60 * 1000
    private val logMaxBytes = 30L * 1024 * 1024
    private fun pruneOldLogs() {
        val dir = getExternalFilesDir(null) ?: return
        val logs = dir.listFiles()?.filter {
            it.isFile && it.name.matches(Regex("fogradar_[0-9]+\\.csv")) && it != activeLogFile
        }?.sortedByDescending { it.lastModified() } ?: return
        val now = System.currentTimeMillis()
        var total = 0L
        for (file in logs) {
            val expired = now - file.lastModified() > logMaxAgeMs
            if (expired || total + file.length() > logMaxBytes) {
                file.delete()
            } else {
                total += file.length()
            }
        }
    }
    private var activeLogFile: File? = null
    private var tone: android.media.ToneGenerator? = null
    private var beepAt = 0L
    private val parser = RadarParser { snap ->
        latest.set(snap); frameCount++; recentFrame=SystemClock.elapsedRealtime()
        runOnUiThread { tracks.measure(snap,params) }
        try { logWriter?.apply {
            val ts=System.currentTimeMillis(); write("F,$ts,${snap.raw.joinToString(""){ "%02X".format(it.toInt() and 255) }}\n")
            snap.targets.forEach { write("T,$ts,${it.angle},${it.range},${if(it.approaching) 1 else 0},${it.speed},${it.snr}\n") }
            flush()
        } } catch (_: Exception) { }
    }
    override fun onCreate(state: Bundle?) { super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        params=Params(
            laneWidth=prefs.getFloat("laneWidth",3.5f),radarOffset=prefs.getFloat("radarOffset",0f),
            yaw=prefs.getFloat("yaw",0f),rangeBias=prefs.getFloat("rangeBias",0f),
            laneShift=prefs.getFloat("laneShift",0f),snrMin=prefs.getInt("snrMin",4),
            keepSeconds=prefs.getFloat("keepSeconds",1f),staleMs=prefs.getLong("staleMs",650),
            alarmEnabled=prefs.getBoolean("alarm",false),maxRange=prefs.getInt("maxRange",99),showAngles=true,direction=prefs.getInt("direction",0),speedMin=prefs.getInt("speedMin",0),speedMax=prefs.getInt("speedMax",120))
        manualSpeedKmh=prefs.getFloat("manualSpeed",0f).toDouble()
        pruneOldLogs()
        sensors=getSystemService(SENSOR_SERVICE) as SensorManager
        sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_GAME) }
        gpsManager=getSystemService(LOCATION_SERVICE) as LocationManager
        lastPhysicsMs=SystemClock.elapsedRealtime()
        adapter=(getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        tone=try { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC,55) }catch(_:Exception){null}
        primary=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(10,8,10,4);setBackgroundColor(Color.rgb(7,17,28))}
        status=TextView(this).apply{setTextColor(Color.WHITE);textSize=12f;text="未连接 · 请搜索LD2451"}
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        btnConnect=Button(this).apply{text="搜索";textSize=12f;setAllCaps(false);setOnClickListener{requestScan()}}
        val log=Button(this).apply{text="开始";textSize=12f;setAllCaps(false);setOnClickListener {if(logWriter==null){
            val f=File(getExternalFilesDir(null),"fogradar_${System.currentTimeMillis()}.csv")
            activeLogFile=f
            logWriter=f.bufferedWriter();logWriter?.write("TYPE,TIMESTAMP,HEX_OR_ANGLE,DISTANCE,DIRECTION,SPEED,SNR\n");logWriter?.flush();text="停止";Toast.makeText(this@MainActivity,f.absolutePath,Toast.LENGTH_LONG).show()
        } else{logWriter?.close();logWriter=null;activeLogFile=null;pruneOldLogs();text="开始"}}}
        recordButton=log
        val share=Button(this).apply{text="导出";textSize=12f;setAllCaps(false);setOnClickListener{exportCsv()}}
        val settings=Button(this).apply{text="设置";textSize=12f;setAllCaps(false);setOnClickListener{showSettings()}}
        for (b in arrayOf(btnConnect,log,share,settings))buttons.addView(b,LinearLayout.LayoutParams(0,-2,1f))
        radarView=RadarView(this)
        primary.addView(buttons)
        primary.addView(status)
        primary.addView(radarView,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(primary)
        handler.post(object:Runnable {override fun run(){
            val now=SystemClock.elapsedRealtime()
            val elapsed=((now-lastPhysicsMs).coerceIn(0,100)).toDouble()/1000.0
            lastPhysicsMs=now
            if(!useGpsSpeed) speedKmh=manualSpeedKmh
            else if(now-lastGpsSpeedMs>3000) speedKmh=0.0
            tracks.predict(elapsed,speedKmh/3.6,yawRate)
            val snap=latest.get();val age=if(snap==null) Long.MAX_VALUE else now-snap.timeMs
            val valid=connected && age<=params.staleMs
            radarView.update(tracks.visible(now,params.keepSeconds),params)
            status.text=if(!connected) "未连接 | BLE $blePacketCount | 帧 $frameCount" else "BLE $blePacketCount | 帧 $frameCount | 目标 ${tracks.confirmedCount(now)} | 车速 ${"%.0f".format(speedKmh)}km/h"
            if(params.alarmEnabled && valid && snap!=null){val near=snap.targets.filter{it.approaching&&it.range in 1..99&&it.snr>=params.snrMin}.minByOrNull{it.range};if(near!=null){val interval=(100+4900*(near.range/100.0).pow(1.5)).toLong().coerceAtLeast(150);if(now-beepAt>=interval){tone?.startTone(android.media.ToneGenerator.TONE_PROP_BEEP,100);beepAt=now}}}
            handler.postDelayed(this,33)
        }})
    }
    private fun onBleBytes(bytes: ByteArray) {
        blePacketCount++
        lastBleAt=SystemClock.elapsedRealtime()
        try { synchronized(this) {
            logWriter?.apply {
                write("B,${System.currentTimeMillis()},${bytes.joinToString(""){ "%02X".format(it.toInt() and 255) }}\n")
                flush()
            }
        } } catch (_: Exception) {}
        parser.feed(bytes)
    }
    private fun exportCsv() {
        try {
            synchronized(this) { logWriter?.flush() }
            val dir=getExternalFilesDir(null) ?: return
            val last=dir.listFiles()?.filter { it.name.endsWith(".csv") }?.maxByOrNull { it.lastModified() }
            if(last==null){Toast.makeText(this,"暂无记录文件，请先点击开始记录",Toast.LENGTH_LONG).show();return}
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="text/csv"
                putExtra(Intent.EXTRA_TITLE,last.name)
            }
            exportPending=last
            startActivityForResult(intent,205)
        } catch(e:Exception){Toast.makeText(this,e.message,Toast.LENGTH_LONG).show()}
    }
    private var exportPending:File?=null
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==205 && resultCode==RESULT_OK){
            val target=data?.data ?: return
            try { contentResolver.openOutputStream(target)?.use { out -> exportPending?.inputStream()?.use { it.copyTo(out) } }
                Toast.makeText(this,"记录已导出",Toast.LENGTH_SHORT).show()
            } catch(e:Exception){Toast.makeText(this,"导出失败：${e.message}",Toast.LENGTH_LONG).show()}
        }
    }
    private fun permitted():Boolean = if(Build.VERSION.SDK_INT>=31) checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    private fun requestScan(){if(!permitted()){if(Build.VERSION.SDK_INT>=31)requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),12)else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),12);return};scan()}
    @SuppressLint("MissingPermission") private fun scan(){val bt=adapter;if(bt==null||!bt.isEnabled){startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return}
        val found=linkedMapOf<String,BluetoothDevice>();val cb=object:ScanCallback(){override fun onScanResult(type:Int,r:ScanResult){val name=r.device.name?:r.scanRecord?.deviceName?:"";if(name.contains("LD2451",true)||name.contains("HLK",true))found[r.device.address]=r.device}}
        scanning=true;bt.bluetoothLeScanner?.startScan(cb)
        handler.postDelayed({bt.bluetoothLeScanner?.stopScan(cb);scanning=false;val entries=found.values.toList();if(entries.isEmpty()){Toast.makeText(this,"未扫描到HLK设备",Toast.LENGTH_SHORT).show();return@postDelayed};AlertDialog.Builder(this).setTitle("选择LD2451").setItems(entries.map{(it.name?:"BLE")+"  "+it.address}.toTypedArray()){_,n->connect(entries[n])}.show()},6500)
    }
    @SuppressLint("MissingPermission") private fun connect(device:BluetoothDevice){gatt?.close();connected=false;status.text="正在连接 ${device.address}"
        gatt=device.connectGatt(this,false,object:BluetoothGattCallback(){
            override fun onConnectionStateChange(g:BluetoothGatt,status:Int,newState:Int){if(newState==BluetoothProfile.STATE_CONNECTED){connected=true;g.discoverServices()}else{connected=false;g.close()}}
            override fun onServicesDiscovered(g:BluetoothGatt,status:Int){
                // Official HLK demo routes LD2451 via FFF0 / FFF1 notify / FFF2 write.
                val characteristic=g.getService(serviceUuid)?.getCharacteristic(notifyUuid)
                if(characteristic==null){runOnUiThread{this@MainActivity.status.text="已连接，未找到FFF1特征，请检查雷达服务"};return}
                g.setCharacteristicNotification(characteristic,true)
                val desc=characteristic.getDescriptor(cccd)
                if(desc!=null){if(Build.VERSION.SDK_INT>=33)g.writeDescriptor(desc,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) else {desc.value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;g.writeDescriptor(desc)}} else {runOnUiThread{this@MainActivity.status.text="通知通道无CCCD描述符"}}
            }
            override fun onDescriptorWrite(g:BluetoothGatt,d:BluetoothGattDescriptor,status:Int){if(status==BluetoothGatt.GATT_SUCCESS){g.requestMtu(512)}else{runOnUiThread{this@MainActivity.status.text="通知订阅失败 $status"}}}
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic){if(Build.VERSION.SDK_INT<33)onBleBytes(c.value)}
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic,value:ByteArray){onBleBytes(value)}
        })
    }
    private fun showSettings(){val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,8,22,8)};val scroll=ScrollView(this);scroll.addView(panel)
        fun item(label:String,value:Float,min:Float,max:Float,step:Float,change:(Float)->Unit){val title=TextView(this);panel.addView(title);val seek=SeekBar(this);seek.max=((max-min)/step).roundToInt();seek.progress=((value-min)/step).roundToInt();title.text="$label: $value";seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,user:Boolean){val v=min+p*step;title.text="$label: ${"%.2f".format(v)}";change(v)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}});panel.addView(seek)}
        var p=params
        item("车道宽度 m",p.laneWidth,3f,4.5f,0.1f){p=p.copy(laneWidth=it)}
        item("雷达安装偏移 m",p.radarOffset,-2f,2f,0.1f){p=p.copy(radarOffset=it)}
        item("角度纠偏 °",p.yaw,-15f,15f,0.5f){p=p.copy(yaw=it)}
        item("距离纠偏 m",p.rangeBias,-5f,5f,0.5f){p=p.copy(rangeBias=it)}
        item("车道模型偏移 m",p.laneShift,-5f,5f,0.1f){p=p.copy(laneShift=it)}
        item("SNR阈值",p.snrMin.toFloat(),0f,20f,1f){p=p.copy(snrMin=it.toInt())}
        item("预测虚拟框淡出时间 s",p.keepSeconds,0.2f,10f,0.2f){p=p.copy(keepSeconds=it)}
        item("最远显示距离 m (0=关闭目标显示)",p.maxRange.toFloat(),0f,99f,1f){p=p.copy(maxRange=it.toInt())}
        val speedTitle=TextView(this).apply{text="本车运动预测";textSize=17f};panel.addView(speedTitle)
        item("手动本车速度 km/h",manualSpeedKmh.toFloat(),0f,150f,1f){ manualSpeedKmh=it.toDouble() }
        val gpsSwitch=CheckBox(this).apply { text="使用GPS车速（不使用经纬度参与计算）";isChecked=useGpsSpeed;setOnCheckedChangeListener {_,v-> useGpsSpeed=v;if(v) startGpsSpeed() else stopGpsSpeed() } };panel.addView(gpsSwitch)
        val direction=Spinner(this);direction.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("双向","靠近","远离"));direction.setSelection(p.direction);direction.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent:android.widget.AdapterView<*>?){};override fun onItemSelected(parent:android.widget.AdapterView<*>?, view:View?,pos:Int,id:Long){p=p.copy(direction=pos)} };panel.addView(TextView(this).apply{text="显示目标方向"});panel.addView(direction)
        item("最低显示速度 km/h",p.speedMin.toFloat(),0f,120f,1f){p=p.copy(speedMin=it.toInt())}
        item("最高显示速度 km/h",p.speedMax.toFloat(),0f,120f,1f){p=p.copy(speedMax=it.toInt())}
        item("数据超时 ms",p.staleMs.toFloat(),200f,5000f,100f){p=p.copy(staleMs=it.toLong())}
        val cb=CheckBox(this).apply{text="开启距离蜂鸣（测试）";isChecked=p.alarmEnabled;setOnCheckedChangeListener{_,v->p=p.copy(alarmEnabled=v)}};panel.addView(cb)
        AlertDialog.Builder(this).setTitle("模型校准 / 本地参数").setView(scroll).setNegativeButton("取消",null).setPositiveButton("保存"){_,_->params=p;prefs.edit().putFloat("laneWidth",p.laneWidth).putFloat("radarOffset",p.radarOffset).putFloat("yaw",p.yaw).putFloat("rangeBias",p.rangeBias).putFloat("laneShift",p.laneShift).putInt("snrMin",p.snrMin).putFloat("keepSeconds",p.keepSeconds).putLong("staleMs",p.staleMs).putBoolean("alarm",p.alarmEnabled).putInt("maxRange",p.maxRange).putInt("direction",p.direction).putInt("speedMin",p.speedMin).putInt("speedMax",p.speedMax).putFloat("manualSpeed",manualSpeedKmh.toFloat()).apply()}.show()
    }
    @SuppressLint("MissingPermission") private fun startGpsSpeed() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),44);return}
        try { gpsManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,0f,gpsListener) } catch(_:Exception){}
    }
    private fun stopGpsSpeed(){try{gpsManager?.removeUpdates(gpsListener)}catch(_:Exception){}}
    override fun onDestroy(){super.onDestroy();stopGpsSpeed();sensors.unregisterListener(this);handler.removeCallbacksAndMessages(null);gatt?.close();logWriter?.close();activeLogFile=null;pruneOldLogs();tone?.release()}
}
class RadarView(context:Context): View(context){
    private val pen=Paint(Paint.ANTI_ALIAS_FLAG)
    private var targets=emptyList<TrackedView>()
    private var params=Params()
    fun update(t:List<TrackedView>,p:Params){targets=t;params=p;invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c)
        c.drawColor(Color.rgb(10,27,43));val w=width.toFloat();val h=height.toFloat()
        val left=42f;val right=w-12f;val top=32f;val bottom=h-45f
        val ww=right-left;val hh=bottom-top;val maxD=params.maxRange.coerceAtLeast(1)
        pen.style=Paint.Style.FILL;pen.color=Color.rgb(18,42,62);c.drawRect(left,top,right,bottom,pen)
        pen.color=Color.rgb(27,73,77);val center=left+ww/2;c.drawRect(center-ww/10,top,center+ww/10,bottom,pen)
        for(i in 0..5){pen.color=Color.rgb(88,130,149);pen.strokeWidth=1f;c.drawLine(left+ww*i/5,top,left+ww*i/5,bottom,pen)}
        for(i in 0..10){val y=top+hh*i/10;pen.color=Color.rgb(72,104,125);c.drawLine(left,y,right,y,pen);pen.color=Color.LTGRAY;pen.textSize=11f;c.drawText("${(10-i)*maxD/10}",2f,y+4,pen)}
        pen.textAlign=Paint.Align.CENTER;pen.textSize=12f;pen.color=Color.WHITE
        for(i in 0..4)c.drawText(arrayOf("L2","L1","C","R1","R2")[i],left+ww*(i+.5f)/5,19f,pen)
        if(params.showAngles){for(a in intArrayOf(-15,-10,-5,0,5,10,15)){val dx=tan(Math.toRadians(a.toDouble()))*maxD;pen.color=if(a==0)Color.rgb(81,195,159) else Color.rgb(160,135,77);pen.strokeWidth=1f;c.drawLine(center,bottom,(center+dx/(params.laneWidth*5)*ww).toFloat(),top,pen)}}
        if(params.maxRange>0) targets.forEach{t->
            if(t.y<0||t.y>maxD||abs(t.x)>params.laneWidth*2.5)return@forEach
            val px=(center+t.x/(params.laneWidth*5)*ww).toFloat()
            val py=(bottom-t.y/maxD*hh).toFloat()
            val size=max(28f,min(5f/maxD*hh,5f/(params.laneWidth*5)*ww))
            val half=size/2f
            pen.color=t.color;pen.alpha=(t.alpha*255).toInt().coerceIn(0,255)
            pen.style=Paint.Style.STROKE;pen.strokeWidth=if(t.measured)3f else 2.3f
            pen.pathEffect=if(t.measured)null else DashPathEffect(floatArrayOf(8f,6f),0f)
            c.drawRect(px-half,py-half,px+half,py+half,pen)
            pen.pathEffect=null;pen.style=Paint.Style.FILL;pen.alpha=255
        }
        pen.color=Color.WHITE;pen.textSize=14f;pen.textAlign=Paint.Align.CENTER;c.drawText("雷达位置 / 0m",center,h-15f,pen)
    }
}
