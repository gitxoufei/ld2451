package top.xfwork.fogradar

import android.graphics.Color
import kotlin.math.*

data class TrackedView(val x:Double,val y:Double,val color:Int,val alpha:Float,val measured:Boolean)
private data class Track(var x:Double,var y:Double,val color:Int,var lastSeen:Long,var hits:Int=1,var recentlyMeasured:Boolean=true)
class TargetTracker {
    private val tracks=mutableListOf<Track>()
    private val palette=intArrayOf(0xFFFF5252.toInt(),0xFFFFD740.toInt(),0xFF00E5FF.toInt(),0xFFB388FF.toInt(),0xFF69F0AE.toInt(),0xFFFF9100.toInt(),0xFFFF80AB.toInt(),0xFF40C4FF.toInt(),0xFFE040FB.toInt(),0xFFEEFF41.toInt(),0xFF7C4DFF.toInt(),0xFF64FFDA.toInt())
    private fun color():Int {val used=tracks.map{it.color}.toSet();return palette.filter{it !in used}.randomOrNull()?:palette.random()}
    fun predict(dt:Double,v:Double,omega:Double){
        if(dt<=0.0)return
        val turn=omega*dt
        // Integrate translation on circular arc in the old vehicle coordinates.
        val dx=if(abs(omega)<1e-4)0.0 else (v/omega)*(1-cos(turn))
        val dy=if(abs(omega)<1e-4)v*dt else (v/omega)*sin(turn)
        val cc=cos(turn);val ss=sin(turn)
        for(t in tracks){val x=t.x-dx;val y=t.y-dy;t.x=cc*x-ss*y;t.y=ss*x+cc*y;t.recentlyMeasured=false}
    }
    fun measure(snap:Snapshot,p:Params){
        val now=snap.timeMs
        val measurements=snap.targets.filter {it.snr>=p.snrMin && it.speed in p.speedMin..p.speedMax && (p.direction==0 || (p.direction==1&&it.approaching) || (p.direction==2&&!it.approaching)) }.map{p.xy(it)}
        // Assign the globally closest available pairs first, with a gated distance threshold.
        val options=mutableListOf<Triple<Int,Int,Double>>()
        for(i in measurements.indices)for(j in tracks.indices){val d=hypot(measurements[i].first-tracks[j].x,measurements[i].second-tracks[j].y);if(d<min(15.0,3.5+0.12*measurements[i].second.coerceAtLeast(0.0)))options.add(Triple(i,j,d))}
        val matchedM=mutableSetOf<Int>();val matchedT=mutableSetOf<Int>()
        for((i,j,_) in options.sortedBy{it.third}) {if(i in matchedM||j in matchedT)continue;val t=tracks[j];t.x=measurements[i].first;t.y=measurements[i].second;t.lastSeen=now;t.hits++;t.recentlyMeasured=true;matchedM.add(i);matchedT.add(j)}
        for(i in measurements.indices)if(i !in matchedM)tracks.add(Track(measurements[i].first,measurements[i].second,color(),now))
    }
    fun visible(now:Long,seconds:Float):List<TrackedView>{
        val ttl=(seconds*1000).toLong().coerceAtLeast(100)
        tracks.removeAll{now-it.lastSeen>ttl}
        return tracks.map {t ->
            val age=(now-t.lastSeen).coerceAtLeast(0)
            // Last measurement is visually a solid box very briefly; predicted boxes fade continuously.
            val measured=t.recentlyMeasured && age<60
            val alpha=if(measured)1f else (1.0-age.toDouble()/ttl).coerceIn(0.0,1.0).toFloat()
            TrackedView(t.x,t.y,t.color,alpha,measured)
        }
    }
    fun confirmedCount(now:Long)=tracks.count{now-it.lastSeen<500}
}
