# FogRadar V2.6（回退蓝牙连接修复）

- 蓝牙扫描、连接、FFF0/FFF1通知回退至经实机验证的V2.1代码。
- 删除V2.4以后的BLE心跳、握手检测、自动重连和超时断开。
- 目标仍然只显示实测位置，彩色5m方框；按设置超时直接消失。
- 设置对话框的第一项就是车头/车尾，保存到rearMode；车尾绘图从顶部0m开始。
- 主页面状态标示V2.6以确认实际安装版本。
- 保留CSV原始数据记录、导出、自动清理和屏幕常亮。

构建说明：将FogRadar_GitHub_Cloud_Build_V2_6.zip上传到GitHub仓库，再将仓库中.github/workflows/build-apk.yml里的解压包文件名改为相同的ZIP文件名。原有sed插入AlertDialog命令必须删掉。

注意：这是未经构建或实机验证的源代码修复包。
