package top.xfwork.fogradar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.*

class MainActivity : Activity() {
    private val tracks = TargetTracker()
    private var recordButton: Button? = null
    private val serviceUuid = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    private val notifyUuid = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private var gatt: BluetoothGatt? = null
    private var scanning = false
    private var adapter: BluetoothAdapter? = null
    @Volatile private var connected = false
    @Volatile private var notifyReady = false
    private var reconnecting = false
    private var disconnectReason = "未连接"
    private var lastDevice: BluetoothDevice? = null
    private var retryCount = 0
    private var lastAttemptMs = 0L
    private var linkAtMs = 0L
    private val silentWarningMs = 3000L
    private val silentReconnectMs = 8000L
    private val reconnectGapMs = 5000L
    private val maxAutoRetries = 3
    private var bleStatus = "未连接"
    private var simulated = false
    private var latest = AtomicReference<Snapshot?>(null)
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("fog_params", MODE_PRIVATE) }
    private var params = Params()
    private lateinit var radarView: RadarView
    private lateinit var status: TextView
    private lateinit var primary: LinearLayout
    private lateinit var btnConnect: Button
    private var blePacketCount = 0L
    @Volatile private var lastBleAt = 0L
    private var frameCount = 0L
    private var recentFrame = 0L
    private var logWriter: java.io.BufferedWriter? = null
    // Only manage FogRadar session logs; never touch other applications' directories.
    private val logMaxAgeMs = 7L * 24 * 60 * 60 * 1000
    private val logMaxBytes = 30L * 1024 * 1024
    private fun pruneOldLogs() {
        val dir = getExternalFilesDir(null) ?: return
        val logs = dir.listFiles()?.filter {
            it.isFile && it.name.matches(Regex("fogradar_[0-9]+\\.csv")) && it != activeLogFile
        }?.sortedByDescending { it.lastModified() } ?: return
        val now = System.currentTimeMillis()
        var total = 0L
        for (file in logs) {
            val expired = now - file.lastModified() > logMaxAgeMs
            if (expired || total + file.length() > logMaxBytes) {
                file.delete()
            } else {
                total += file.length()
            }
        }
    }
    private var activeLogFile: File? = null
    private var tone: android.media.ToneGenerator? = null
    private var beepAt = 0L
    private val parser = RadarParser { snap ->
        latest.set(snap); frameCount++; recentFrame=SystemClock.elapsedRealtime()
        runOnUiThread { tracks.measure(snap,params) }
        try { logWriter?.apply {
            val ts=System.currentTimeMillis(); write("F,$ts,${snap.raw.joinToString(""){ "%02X".format(it.toInt() and 255) }}\n")
            snap.targets.forEach { write("T,$ts,${it.angle},${it.range},${if(it.approaching) 1 else 0},${it.speed},${it.snr}\n") }
            flush()
        } } catch (_: Exception) { }
    }
    override fun onCreate(state: Bundle?) { super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        params=Params(
            laneWidth=prefs.getFloat("laneWidth",3.5f),radarOffset=prefs.getFloat("radarOffset",0f),
            yaw=prefs.getFloat("yaw",0f),rangeBias=prefs.getFloat("rangeBias",0f),
            laneShift=prefs.getFloat("laneShift",0f),snrMin=prefs.getInt("snrMin",4),
            keepSeconds=prefs.getFloat("keepSeconds",1f),staleMs=prefs.getLong("staleMs",650),
            alarmEnabled=prefs.getBoolean("alarm",false),maxRange=prefs.getInt("maxRange",99),showAngles=true,direction=prefs.getInt("direction",0),speedMin=prefs.getInt("speedMin",0),speedMax=prefs.getInt("speedMax",120))
        pruneOldLogs()
        adapter=(getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        tone=try { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC,55) }catch(_:Exception){null}
        primary=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(10,8,10,4);setBackgroundColor(Color.rgb(7,17,28))}
        status=TextView(this).apply{setTextColor(Color.WHITE);textSize=12f;text="未连接 · 请搜索LD2451"}
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        btnConnect=Button(this).apply{text="搜索";textSize=12f;setAllCaps(false);setOnClickListener{requestScan()}}
        val log=Button(this).apply{text="开始";textSize=12f;setAllCaps(false);setOnClickListener {if(logWriter==null){
            val f=File(getExternalFilesDir(null),"fogradar_${System.currentTimeMillis()}.csv")
            activeLogFile=f
            logWriter=f.bufferedWriter();logWriter?.write("TYPE,TIMESTAMP,HEX_OR_ANGLE,DISTANCE,DIRECTION,SPEED,SNR\n");logWriter?.flush();text="停止";Toast.makeText(this@MainActivity,f.absolutePath,Toast.LENGTH_LONG).show()
        } else{logWriter?.close();logWriter=null;activeLogFile=null;pruneOldLogs();text="开始"}}}
        recordButton=log
        val share=Button(this).apply{text="导出";textSize=12f;setAllCaps(false);setOnClickListener{exportCsv()}}
        val settings=Button(this).apply{text="设置";textSize=12f;setAllCaps(false);setOnClickListener{showSettings()}}
        for (b in arrayOf(btnConnect,log,share,settings))buttons.addView(b,LinearLayout.LayoutParams(0,-2,1f))
        radarView=RadarView(this)
        primary.addView(buttons)
        primary.addView(status)
        primary.addView(radarView,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(primary)
        handler.post(object:Runnable {override fun run(){
            val now=SystemClock.elapsedRealtime()
            // No IMU/GPS, virtual boxes, or extrapolated motion.
            val snap=latest.get();val age=if(snap==null) Long.MAX_VALUE else now-snap.timeMs
            val valid=connected && notifyReady && age<=params.staleMs && now-lastBleAt<silentWarningMs
            radarView.update(if(connected && notifyReady)tracks.visible(now,params.keepSeconds) else emptyList(),params)
            val effectiveSilence = if(lastBleAt>linkAtMs) now-lastBleAt else now-linkAtMs
            if(reconnecting && now-lastAttemptMs>=12000L){reconnecting=false;disconnectReason="连接等待超时"}
            if(connected && !notifyReady && effectiveSilence>=silentReconnectMs && !reconnecting){
                scheduleReconnect("通知初始化超时",now)
            } else if(connected && notifyReady && effectiveSilence>=silentReconnectMs && !reconnecting){
                scheduleReconnect("数据流中断${effectiveSilence/1000}s",now)
            } else if(!connected && !reconnecting && lastDevice!=null && retryCount in 0 until maxAutoRetries && now-lastAttemptMs>=reconnectGapMs){
                scheduleReconnect("连接中断",now)
            }
            val state = when {
                reconnecting -> "重连中 ${retryCount}/$maxAutoRetries"
                !connected -> "断开：$disconnectReason"
                !notifyReady -> "蓝牙已连，通知未就绪"
                lastBleAt<=linkAtMs -> "已订阅，等待数据 ${effectiveSilence/1000}s"
                effectiveSilence>=silentWarningMs -> "数据中断 ${effectiveSilence/1000}s"
                else -> "通信正常 ${effectiveSilence}ms"
            }
            status.text="$state | BLE $blePacketCount | 帧 $frameCount | 目标 ${tracks.confirmedCount(now)}"
            status.setTextColor(when {
                !connected || reconnecting || (notifyReady && effectiveSilence>=silentReconnectMs) -> Color.rgb(255,104,104)
                !notifyReady || effectiveSilence>=silentWarningMs -> Color.rgb(255,206,76)
                else -> Color.rgb(103,240,163)
            })
            if(params.alarmEnabled && valid && snap!=null){val near=snap.targets.filter{it.approaching&&it.range in 1..99&&it.snr>=params.snrMin}.minByOrNull{it.range};if(near!=null){val interval=(100+4900*(near.range/100.0).pow(1.5)).toLong().coerceAtLeast(150);if(now-beepAt>=interval){tone?.startTone(android.media.ToneGenerator.TONE_PROP_BEEP,100);beepAt=now}}}
            handler.postDelayed(this,33)
        }})
    }
    private fun onBleBytes(bytes: ByteArray) {
        blePacketCount++
        lastBleAt=SystemClock.elapsedRealtime()
        // Successful notifications, including no-target frames, prove data path liveness.
        retryCount=0
        try { synchronized(this) {
            logWriter?.apply {
                write("B,${System.currentTimeMillis()},${bytes.joinToString(""){ "%02X".format(it.toInt() and 255) }}\n")
                flush()
            }
        } } catch (_: Exception) {}
        parser.feed(bytes)
    }
    private fun exportCsv() {
        try {
            synchronized(this) { logWriter?.flush() }
            val dir=getExternalFilesDir(null) ?: return
            val last=dir.listFiles()?.filter { it.name.endsWith(".csv") }?.maxByOrNull { it.lastModified() }
            if(last==null){Toast.makeText(this,"暂无记录文件，请先点击开始记录",Toast.LENGTH_LONG).show();return}
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="text/csv"
                putExtra(Intent.EXTRA_TITLE,last.name)
            }
            exportPending=last
            startActivityForResult(intent,205)
        } catch(e:Exception){Toast.makeText(this,e.message,Toast.LENGTH_LONG).show()}
    }
    private var exportPending:File?=null
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==205 && resultCode==RESULT_OK){
            val target=data?.data ?: return
            try { contentResolver.openOutputStream(target)?.use { out -> exportPending?.inputStream()?.use { it.copyTo(out) } }
                Toast.makeText(this,"记录已导出",Toast.LENGTH_SHORT).show()
            } catch(e:Exception){Toast.makeText(this,"导出失败：${e.message}",Toast.LENGTH_LONG).show()}
        }
    }
    private fun permitted():Boolean = if(Build.VERSION.SDK_INT>=31) checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    private fun requestScan(){if(!permitted()){if(Build.VERSION.SDK_INT>=31)requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),12)else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),12);return};scan()}
    @SuppressLint("MissingPermission") private fun scan(){val bt=adapter;if(bt==null||!bt.isEnabled){startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return}
        val found=linkedMapOf<String,BluetoothDevice>();val cb=object:ScanCallback(){override fun onScanResult(type:Int,r:ScanResult){val name=r.device.name?:r.scanRecord?.deviceName?:"";if(name.contains("LD2451",true)||name.contains("HLK",true))found[r.device.address]=r.device}}
        scanning=true;bt.bluetoothLeScanner?.startScan(cb)
        handler.postDelayed({bt.bluetoothLeScanner?.stopScan(cb);scanning=false;val entries=found.values.toList();if(entries.isEmpty()){Toast.makeText(this,"未扫描到HLK设备",Toast.LENGTH_SHORT).show();return@postDelayed};AlertDialog.Builder(this).setTitle("选择LD2451").setItems(entries.map{(it.name?:"BLE")+"  "+it.address}.toTypedArray()){_,n->connect(entries[n])}.show()},6500)
    }
    private fun scheduleReconnect(reason:String,now:Long=SystemClock.elapsedRealtime()) {
        if(reconnecting || lastDevice==null || retryCount>=maxAutoRetries) {
            if(retryCount>=maxAutoRetries) disconnectReason="自动重连已达上限，请点搜索"
            return
        }
        if(now-lastAttemptMs<reconnectGapMs)return
        reconnecting=true
        retryCount++
        disconnectReason=reason
        lastAttemptMs=now
        val device=lastDevice ?: return
        handler.post { connect(device,true) }
    }
    @SuppressLint("MissingPermission") private fun connect(device:BluetoothDevice,auto:Boolean=false){
        if(!auto){retryCount=0;lastAttemptMs=SystemClock.elapsedRealtime()}
        lastDevice=device
        gatt?.disconnect();gatt?.close();connected=false;notifyReady=false
        lastBleAt=0L;linkAtMs=SystemClock.elapsedRealtime();reconnecting=auto
        status.text=if(auto)"正在重连 ${device.address}" else "正在连接 ${device.address}"
        gatt=device.connectGatt(this,false,object:BluetoothGattCallback(){
            override fun onConnectionStateChange(g:BluetoothGatt,status:Int,newState:Int){
                if(g!==gatt)return
                if(newState==BluetoothProfile.STATE_CONNECTED && status==BluetoothGatt.GATT_SUCCESS){
                    connected=true;linkAtMs=SystemClock.elapsedRealtime();reconnecting=false
                    if(!g.discoverServices()) {notifyReady=false;disconnectReason="服务发现启动失败";scheduleReconnect(disconnectReason)}
                }else{
                    connected=false;notifyReady=false;reconnecting=false
                    disconnectReason="GATT状态 $status"
                    runOnUiThread { if(g===gatt) {gatt=null;try{g.close()}catch(_:Exception){};scheduleReconnect(disconnectReason)} }
                }
            }
            override fun onServicesDiscovered(g:BluetoothGatt,status:Int){
                // Official HLK demo routes LD2451 via FFF0 / FFF1 notify / FFF2 write.
                if(g!==gatt)return
                if(status!=BluetoothGatt.GATT_SUCCESS){disconnectReason="服务发现失败 $status";return}
                val characteristic=g.getService(serviceUuid)?.getCharacteristic(notifyUuid)
                if(characteristic==null){runOnUiThread{this@MainActivity.status.text="已连接，未找到FFF1特征，请检查雷达服务"};return}
                if(!g.setCharacteristicNotification(characteristic,true)){disconnectReason="启用BLE通知失败";return}
                val desc=characteristic.getDescriptor(cccd)
                if(desc!=null){if(Build.VERSION.SDK_INT>=33)g.writeDescriptor(desc,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) else {desc.value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;g.writeDescriptor(desc)}} else {runOnUiThread{this@MainActivity.status.text="通知通道无CCCD描述符"}}
            }
            override fun onDescriptorWrite(g:BluetoothGatt,d:BluetoothGattDescriptor,status:Int){
                if(g!==gatt)return
                if(status==BluetoothGatt.GATT_SUCCESS){
                    notifyReady=true;reconnecting=false
                    linkAtMs=SystemClock.elapsedRealtime()
                    g.requestMtu(512)
                }else{notifyReady=false;disconnectReason="通知订阅失败 $status"}
            }
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic){if(Build.VERSION.SDK_INT<33)onBleBytes(c.value)}
            override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic,value:ByteArray){onBleBytes(value)}
        })
    }
    private fun showSettings(){val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,8,22,8)};val scroll=ScrollView(this);scroll.addView(panel)
        fun item(label:String,value:Float,min:Float,max:Float,step:Float,change:(Float)->Unit){val title=TextView(this);panel.addView(title);val seek=SeekBar(this);seek.max=((max-min)/step).roundToInt();seek.progress=((value-min)/step).roundToInt();title.text="$label: $value";seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,user:Boolean){val v=min+p*step;title.text="$label: ${"%.2f".format(v)}";change(v)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}});panel.addView(seek)}
        var p=params
        item("车道宽度 m",p.laneWidth,3f,4.5f,0.1f){p=p.copy(laneWidth=it)}
        item("雷达安装偏移 m",p.radarOffset,-2f,2f,0.1f){p=p.copy(radarOffset=it)}
        item("角度纠偏 °",p.yaw,-15f,15f,0.5f){p=p.copy(yaw=it)}
        item("距离纠偏 m",p.rangeBias,-5f,5f,0.5f){p=p.copy(rangeBias=it)}
        item("车道模型偏移 m",p.laneShift,-5f,5f,0.1f){p=p.copy(laneShift=it)}
        item("SNR阈值",p.snrMin.toFloat(),0f,20f,1f){p=p.copy(snrMin=it.toInt())}
        item("目标消失超时 s",p.keepSeconds,0.2f,10f,0.2f){p=p.copy(keepSeconds=it)}
        item("最远显示距离 m (0=关闭目标显示)",p.maxRange.toFloat(),0f,99f,1f){p=p.copy(maxRange=it.toInt())}
        val direction=Spinner(this);direction.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("双向","靠近","远离"));direction.setSelection(p.direction);direction.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent:android.widget.AdapterView<*>?){};override fun onItemSelected(parent:android.widget.AdapterView<*>?, view:View?,pos:Int,id:Long){p=p.copy(direction=pos)} };panel.addView(TextView(this).apply{text="显示目标方向"});panel.addView(direction)
        item("最低显示速度 km/h",p.speedMin.toFloat(),0f,120f,1f){p=p.copy(speedMin=it.toInt())}
        item("最高显示速度 km/h",p.speedMax.toFloat(),0f,120f,1f){p=p.copy(speedMax=it.toInt())}
        item("数据超时 ms",p.staleMs.toFloat(),200f,5000f,100f){p=p.copy(staleMs=it.toLong())}
        val cb=CheckBox(this).apply{text="开启距离蜂鸣（测试）";isChecked=p.alarmEnabled;setOnCheckedChangeListener{_,v->p=p.copy(alarmEnabled=v)}};panel.addView(cb)
        AlertDialog.Builder(this).setTitle("模型校准 / 本地参数").setView(scroll).setNegativeButton("取消",null).setPositiveButton("保存"){_,_->params=p;prefs.edit().putFloat("laneWidth",p.laneWidth).putFloat("radarOffset",p.radarOffset).putFloat("yaw",p.yaw).putFloat("rangeBias",p.rangeBias).putFloat("laneShift",p.laneShift).putInt("snrMin",p.snrMin).putFloat("keepSeconds",p.keepSeconds).putLong("staleMs",p.staleMs).putBoolean("alarm",p.alarmEnabled).putInt("maxRange",p.maxRange).putInt("direction",p.direction).putInt("speedMin",p.speedMin).putInt("speedMax",p.speedMax).apply()}.show()
    }
    override fun onDestroy(){super.onDestroy();handler.removeCallbacksAndMessages(null);try{gatt?.disconnect()}catch(_:Exception){};gatt?.close();logWriter?.close();activeLogFile=null;pruneOldLogs();tone?.release()}

}
class RadarView(context:Context): View(context){
    private val pen=Paint(Paint.ANTI_ALIAS_FLAG)
    private var targets=emptyList<TrackedView>()
    private var params=Params()
    fun update(t:List<TrackedView>,p:Params){targets=t;params=p;invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c)
        c.drawColor(Color.rgb(10,27,43));val w=width.toFloat();val h=height.toFloat()
        val left=42f;val right=w-12f;val top=32f;val bottom=h-45f
        val ww=right-left;val hh=bottom-top;val maxD=params.maxRange.coerceAtLeast(1)
        pen.style=Paint.Style.FILL;pen.color=Color.rgb(18,42,62);c.drawRect(left,top,right,bottom,pen)
        pen.color=Color.rgb(27,73,77);val center=left+ww/2;c.drawRect(center-ww/10,top,center+ww/10,bottom,pen)
        for(i in 0..5){pen.color=Color.rgb(88,130,149);pen.strokeWidth=1f;c.drawLine(left+ww*i/5,top,left+ww*i/5,bottom,pen)}
        for(i in 0..10){val y=top+hh*i/10;pen.color=Color.rgb(72,104,125);c.drawLine(left,y,right,y,pen);pen.color=Color.LTGRAY;pen.textSize=11f;c.drawText("${(10-i)*maxD/10}",2f,y+4,pen)}
        pen.textAlign=Paint.Align.CENTER;pen.textSize=12f;pen.color=Color.WHITE
        for(i in 0..4)c.drawText(arrayOf("L2","L1","C","R1","R2")[i],left+ww*(i+.5f)/5,19f,pen)
        if(params.showAngles){for(a in intArrayOf(-15,-10,-5,0,5,10,15)){val dx=tan(Math.toRadians(a.toDouble()))*maxD;pen.color=if(a==0)Color.rgb(81,195,159) else Color.rgb(160,135,77);pen.strokeWidth=1f;c.drawLine(center,bottom,(center+dx/(params.laneWidth*5)*ww).toFloat(),top,pen)}}
        if(params.maxRange>0) targets.forEach{t->
            if(t.y<0||t.y>maxD||abs(t.x)>params.laneWidth*2.5)return@forEach
            val px=(center+t.x/(params.laneWidth*5)*ww).toFloat()
            val py=(bottom-t.y/maxD*hh).toFloat()
            val size=max(28f,min(5f/maxD*hh,5f/(params.laneWidth*5)*ww))
            val half=size/2f
            pen.color=t.color;pen.alpha=255
            pen.style=Paint.Style.STROKE;pen.strokeWidth=3f
            pen.pathEffect=null
            c.drawRect(px-half,py-half,px+half,py+half,pen)
            pen.pathEffect=null;pen.style=Paint.Style.FILL;pen.alpha=255
        }
        pen.color=Color.WHITE;pen.textSize=14f;pen.textAlign=Paint.Align.CENTER;c.drawText("雷达位置 / 0m",center,h-15f,pen)
    }
}
